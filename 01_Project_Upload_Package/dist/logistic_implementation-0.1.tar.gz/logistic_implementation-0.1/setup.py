from setuptools import setup

setup(name='logistic_implementation',
      version='0.1',
      description='Implementation of Logist Regression algorithm using OOP',
      packages=['logistic_implementation'],
      zip_safe=False)
